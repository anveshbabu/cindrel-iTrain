export {commonComponentsExample} from './commonComponent'
