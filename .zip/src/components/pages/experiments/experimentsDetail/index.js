import ToggleButton from '@mui/material/ToggleButton';
import ToggleButtonGroup from '@mui/material/ToggleButtonGroup';
import IconButton from '@mui/material/IconButton';
import { CheckCircle, CloseOutlined } from '@mui/icons-material';
import { Normalselect, NormalRadioButtion, NormalButton } from '../../../common'
import { history } from '../../../../helpers'
import './experimentDetail.scss';
import { useParams } from "react-router-dom";
import { useEffect, useState } from 'react';
import { getExperimentsImageList } from '../../../../redux/actions/experiments';
import { getStorage, removeDuplicateArray} from '../../../../services/helperFunctions'
import { EXIST_LOCAL_STORAGE } from '../../../../services/constants';

export const ExperimentsDetail = () => {
    const params = useParams();
    const [userDetail, setUserDetail] = useState(null)
    const [imagesList, setImagesList] = useState([
        {
            "ClassificationName": "healthy",
            "Reviewed": true,
            "class_id": 41,
            "corected_class_name": null,
            "correct": true,
            "corrected_class_id": null,
            "corrections": [
                {
                    "ClassificationName": "scab",
                    "class_id": 38,
                    "corected_class_name": "scab",
                    "corrected_class_id": 38,
                    "date_modified": "Wed, 13 Jul 2022 18:04:13 GMT",
                    "firstname": null,
                    "id": 1,
                    "lastname": null,
                    "modified_by": 2,
                    "test_id": 2
                },
                {
                    "ClassificationName": "scab",
                    "class_id": 38,
                    "corected_class_name": "scab",
                    "corrected_class_id": 38,
                    "date_modified": "Wed, 13 Jul 2022 18:04:13 GMT",
                    "firstname": null,
                    "id": 2,
                    "lastname": null,
                    "modified_by": 2,
                    "test_id": 3
                }
            ],
            "date_added": "Sat, 18 Jun 2022 18:36:37 GMT",
            "date_modified": null,
            "firstname": null,
            "id": 1,
            "image_name": "img_1655577394_64843.png",
            "image_path": "model_uploads/10/images/41/img_1655577394_64843.png",
            "lastname": null,
            "model_id": 5,
            "modified_by": null,
            "score": "1",
            "status": "New",
            "user_id": 2
        },
        {
            "ClassificationName": "scab",
            "Reviewed": true,
            "class_id": 38,
            "corected_class_name": "scab",
            "correct": true,
            "corrected_class_id": 38,
            "corrections": [
                {
                    "ClassificationName": "scab",
                    "class_id": 38,
                    "corected_class_name": "scab",
                    "corrected_class_id": 38,
                    "date_modified": "Wed, 13 Jul 2022 18:04:13 GMT",
                    "firstname": null,
                    "id": 1,
                    "lastname": null,
                    "modified_by": 2,
                    "test_id": 2
                },
                {
                    "ClassificationName": "scab",
                    "class_id": 38,
                    "corected_class_name": "scab",
                    "corrected_class_id": 38,
                    "date_modified": "Wed, 13 Jul 2022 18:04:13 GMT",
                    "firstname": null,
                    "id": 2,
                    "lastname": null,
                    "modified_by": 2,
                    "test_id": 3
                }
            ],
            "date_added": "Sat, 18 Jun 2022 18:36:39 GMT",
            "date_modified": "Wed, 13 Jul 2022 18:04:13 GMT",
            "firstname": null,
            "id": 2,
            "image_name": "img_1655577397_89622.png",
            "image_path": "model_uploads/10/images/38/img_1655577397_89622.png",
            "lastname": null,
            "model_id": 5,
            "modified_by": 2,
            "score": "1",
            "status": "Updated",
            "user_id": 2
        },
        {
            "ClassificationName": "scab",
            "Reviewed": true,
            "class_id": 38,
            "corected_class_name": "scab",
            "correct": true,
            "corrected_class_id": 38,
            "corrections": [
                {
                    "ClassificationName": "scab",
                    "class_id": 38,
                    "corected_class_name": "scab",
                    "corrected_class_id": 38,
                    "date_modified": "Wed, 13 Jul 2022 18:04:13 GMT",
                    "firstname": null,
                    "id": 1,
                    "lastname": null,
                    "modified_by": 2,
                    "test_id": 2
                },
                {
                    "ClassificationName": "scab",
                    "class_id": 38,
                    "corected_class_name": "scab",
                    "corrected_class_id": 38,
                    "date_modified": "Wed, 13 Jul 2022 18:04:13 GMT",
                    "firstname": null,
                    "id": 2,
                    "lastname": null,
                    "modified_by": 2,
                    "test_id": 3
                }
            ],
            "date_added": "Sat, 18 Jun 2022 18:36:41 GMT",
            "date_modified": "Wed, 13 Jul 2022 18:04:13 GMT",
            "firstname": null,
            "id": 3,
            "image_name": "img_1655577399_25776.JPG",
            "image_path": "model_uploads/10/images/38/img_1655577399_25776.JPG",
            "lastname": null,
            "model_id": 5,
            "modified_by": 2,
            "score": "1",
            "status": "Updated",
            "user_id": 2
        },
        {
            "ClassificationName": "healthy",
            "Reviewed": true,
            "class_id": 41,
            "corected_class_name": null,
            "correct": true,
            "corrected_class_id": null,
            "corrections": [
                {
                    "ClassificationName": "scab",
                    "class_id": 38,
                    "corected_class_name": "scab",
                    "corrected_class_id": 38,
                    "date_modified": "Wed, 13 Jul 2022 18:04:13 GMT",
                    "firstname": null,
                    "id": 1,
                    "lastname": null,
                    "modified_by": 2,
                    "test_id": 2
                },
                {
                    "ClassificationName": "scab",
                    "class_id": 38,
                    "corected_class_name": "scab",
                    "corrected_class_id": 38,
                    "date_modified": "Wed, 13 Jul 2022 18:04:13 GMT",
                    "firstname": null,
                    "id": 2,
                    "lastname": null,
                    "modified_by": 2,
                    "test_id": 3
                }
            ],
            "date_added": "Sat, 18 Jun 2022 18:41:30 GMT",
            "date_modified": null,
            "firstname": null,
            "id": 4,
            "image_name": "img_1655577687_63330.png",
            "image_path": "model_uploads/10/images/41/img_1655577687_63330.png",
            "lastname": null,
            "model_id": 5,
            "modified_by": null,
            "score": "1",
            "status": "New",
            "user_id": 2
        },
        {
            "ClassificationName": "scab",
            "Reviewed": true,
            "class_id": 38,
            "corected_class_name": null,
            "correct": true,
            "corrected_class_id": null,
            "corrections": [
                {
                    "ClassificationName": "scab",
                    "class_id": 38,
                    "corected_class_name": "scab",
                    "corrected_class_id": 38,
                    "date_modified": "Wed, 13 Jul 2022 18:04:13 GMT",
                    "firstname": null,
                    "id": 1,
                    "lastname": null,
                    "modified_by": 2,
                    "test_id": 2
                },
                {
                    "ClassificationName": "scab",
                    "class_id": 38,
                    "corected_class_name": "scab",
                    "corrected_class_id": 38,
                    "date_modified": "Wed, 13 Jul 2022 18:04:13 GMT",
                    "firstname": null,
                    "id": 2,
                    "lastname": null,
                    "modified_by": 2,
                    "test_id": 3
                }
            ],
            "date_added": "Sat, 18 Jun 2022 18:41:32 GMT",
            "date_modified": null,
            "firstname": null,
            "id": 5,
            "image_name": "img_1655577689_38581.png",
            "image_path": "model_uploads/10/images/38/img_1655577689_38581.png",
            "lastname": null,
            "model_id": 5,
            "modified_by": null,
            "score": "1",
            "status": "New",
            "user_id": 2
        },
        {
            "ClassificationName": "scab",
            "Reviewed": true,
            "class_id": 38,
            "corected_class_name": null,
            "correct": true,
            "corrected_class_id": null,
            "corrections": [
                {
                    "ClassificationName": "scab",
                    "class_id": 38,
                    "corected_class_name": "scab",
                    "corrected_class_id": 38,
                    "date_modified": "Wed, 13 Jul 2022 18:04:13 GMT",
                    "firstname": null,
                    "id": 1,
                    "lastname": null,
                    "modified_by": 2,
                    "test_id": 2
                },
                {
                    "ClassificationName": "scab",
                    "class_id": 38,
                    "corected_class_name": "scab",
                    "corrected_class_id": 38,
                    "date_modified": "Wed, 13 Jul 2022 18:04:13 GMT",
                    "firstname": null,
                    "id": 2,
                    "lastname": null,
                    "modified_by": 2,
                    "test_id": 3
                }
            ],
            "date_added": "Sat, 18 Jun 2022 18:41:34 GMT",
            "date_modified": null,
            "firstname": null,
            "id": 6,
            "image_name": "img_1655577691_69661.JPG",
            "image_path": "model_uploads/10/images/38/img_1655577691_69661.JPG",
            "lastname": null,
            "model_id": 5,
            "modified_by": null,
            "score": "1",
            "status": "New",
            "user_id": 2
        },
        {
            "ClassificationName": "scab",
            "Reviewed": true,
            "class_id": 38,
            "corected_class_name": null,
            "correct": true,
            "corrected_class_id": null,
            "corrections": [
                {
                    "ClassificationName": "scab",
                    "class_id": 38,
                    "corected_class_name": "scab",
                    "corrected_class_id": 38,
                    "date_modified": "Wed, 13 Jul 2022 18:04:13 GMT",
                    "firstname": null,
                    "id": 1,
                    "lastname": null,
                    "modified_by": 2,
                    "test_id": 2
                },
                {
                    "ClassificationName": "scab",
                    "class_id": 38,
                    "corected_class_name": "scab",
                    "corrected_class_id": 38,
                    "date_modified": "Wed, 13 Jul 2022 18:04:13 GMT",
                    "firstname": null,
                    "id": 2,
                    "lastname": null,
                    "modified_by": 2,
                    "test_id": 3
                }
            ],
            "date_added": "Sun, 26 Jun 2022 16:56:48 GMT",
            "date_modified": null,
            "firstname": null,
            "id": 7,
            "image_name": "img_1656262604_80395.JPG",
            "image_path": "model_uploads/10/images/38/img_1656262604_80395.JPG",
            "lastname": null,
            "model_id": 5,
            "modified_by": null,
            "score": "1",
            "status": "New",
            "user_id": 2
        },
        {
            "ClassificationName": "healthy",
            "Reviewed": true,
            "class_id": 41,
            "corected_class_name": null,
            "correct": true,
            "corrected_class_id": null,
            "corrections": [
                {
                    "ClassificationName": "scab",
                    "class_id": 38,
                    "corected_class_name": "scab",
                    "corrected_class_id": 38,
                    "date_modified": "Wed, 13 Jul 2022 18:04:13 GMT",
                    "firstname": null,
                    "id": 1,
                    "lastname": null,
                    "modified_by": 2,
                    "test_id": 2
                },
                {
                    "ClassificationName": "scab",
                    "class_id": 38,
                    "corected_class_name": "scab",
                    "corrected_class_id": 38,
                    "date_modified": "Wed, 13 Jul 2022 18:04:13 GMT",
                    "firstname": null,
                    "id": 2,
                    "lastname": null,
                    "modified_by": 2,
                    "test_id": 3
                }
            ],
            "date_added": "Sun, 26 Jun 2022 16:57:15 GMT",
            "date_modified": null,
            "firstname": null,
            "id": 8,
            "image_name": "img_1656262633_10332.png",
            "image_path": "model_uploads/10/images/41/img_1656262633_10332.png",
            "lastname": null,
            "model_id": 5,
            "modified_by": null,
            "score": "1",
            "status": "New",
            "user_id": 2
        },
        {
            "ClassificationName": "scab",
            "Reviewed": true,
            "class_id": 38,
            "corected_class_name": null,
            "correct": true,
            "corrected_class_id": null,
            "corrections": [
                {
                    "ClassificationName": "scab",
                    "class_id": 38,
                    "corected_class_name": "scab",
                    "corrected_class_id": 38,
                    "date_modified": "Wed, 13 Jul 2022 18:04:13 GMT",
                    "firstname": null,
                    "id": 1,
                    "lastname": null,
                    "modified_by": 2,
                    "test_id": 2
                },
                {
                    "ClassificationName": "scab",
                    "class_id": 38,
                    "corected_class_name": "scab",
                    "corrected_class_id": 38,
                    "date_modified": "Wed, 13 Jul 2022 18:04:13 GMT",
                    "firstname": null,
                    "id": 2,
                    "lastname": null,
                    "modified_by": 2,
                    "test_id": 3
                }
            ],
            "date_added": "Sun, 26 Jun 2022 16:57:17 GMT",
            "date_modified": null,
            "firstname": null,
            "id": 9,
            "image_name": "img_1656262635_51169.png",
            "image_path": "model_uploads/10/images/38/img_1656262635_51169.png",
            "lastname": null,
            "model_id": 5,
            "modified_by": null,
            "score": "1",
            "status": "New",
            "user_id": 2
        },
        {
            "ClassificationName": "scab",
            "Reviewed": true,
            "class_id": 38,
            "corected_class_name": null,
            "correct": true,
            "corrected_class_id": null,
            "corrections": [
                {
                    "ClassificationName": "scab",
                    "class_id": 38,
                    "corected_class_name": "scab",
                    "corrected_class_id": 38,
                    "date_modified": "Wed, 13 Jul 2022 18:04:13 GMT",
                    "firstname": null,
                    "id": 1,
                    "lastname": null,
                    "modified_by": 2,
                    "test_id": 2
                },
                {
                    "ClassificationName": "scab",
                    "class_id": 38,
                    "corected_class_name": "scab",
                    "corrected_class_id": 38,
                    "date_modified": "Wed, 13 Jul 2022 18:04:13 GMT",
                    "firstname": null,
                    "id": 2,
                    "lastname": null,
                    "modified_by": 2,
                    "test_id": 3
                }
            ],
            "date_added": "Sun, 26 Jun 2022 16:57:19 GMT",
            "date_modified": null,
            "firstname": null,
            "id": 10,
            "image_name": "img_1656262637_76323.JPG",
            "image_path": "model_uploads/10/images/38/img_1656262637_76323.JPG",
            "lastname": null,
            "model_id": 5,
            "modified_by": null,
            "score": "1",
            "status": "New",
            "user_id": 2
        }
    ]);
    const [isImageLoader, setIsImageLoader] = useState(false);


    useEffect(() => {
        let userDetail = getStorage(EXIST_LOCAL_STORAGE.USER_DETAIL)
        setUserDetail(JSON.parse(userDetail));
        handleGetExperimentImages();
    }, [])


    const handleGetExperimentImages = () => {

        let body = {
            user_id: userDetail?.UserId,
            model_id: params?.modelId
        }
        setIsImageLoader(true)
        getExperimentsImageList(body).then(({ status, tests }) => {
            setIsImageLoader(false)

        }).catch((error) => {
            setIsImageLoader(false)
        })

    }





    return (
        <div className='experiment-detail'>
            <div className='row mb-3'>
                <div className='col-md-12'>
                    <div className="card  filter-card border-0">

                        <div className="card-body">
                            <div>
                                <input type="checkbox" className="btn-check " id="correct" autocomplete="off" />
                                <label className="btn btn-outline-primary  rounded-0" rounded-0 for="correct">Correct</label>
                                <input type="checkbox" className="btn-check rounded-0" id="in_correct" autocomplete="off" />
                                <label className="btn btn-outline-primary  rounded-0" for="in_correct">In Correct</label>
                                <input type="checkbox" className="btn-check  rounded-0" id="user" autocomplete="off" />
                                <label className="btn btn-outline-primary  rounded-0" for="user">User</label>
                                <input type="checkbox" className="btn-check  rounded-0" id="reviewed" autocomplete="off" />
                                <label className="btn btn-outline-primary  rounded-0" for="reviewed">Reviewed</label>
                                <input type="checkbox" className="btn-check  rounded-0" id="not_reviewed" autocomplete="off" />
                                <label className="btn btn-outline-primary  rounded-0" for="not_reviewed">Not Reviewed</label>
                                <label className="btn btn-clear rounded-0" for="2222">Clear All Filters</label>
                            </div>

                        </div>


                    </div>
                </div>
            </div>
            <div className='row'>
                <div className='col-md-7'>
                    <div className='row'>
                        {imagesList.map(({ image }) =>

                            <div className='col-md-3 mb-3'>
                                <div className="ratio ratio-1x1">
                                    <img className="img-fluid" src={image} />
                                </div>
                            </div>
                        )}


                    </div>
                </div>
                <div className='col-md-5'>
                    <div className="card border-0">

                        <div className="card-body">
                            <div className='row mb-4'>
                                <div className='col-md-12'>
                                    <div className="ratio ratio-1x1">
                                        <img className="img-fluid" src={'https://fakestoreapi.com/img/81fPKd-2AYL._AC_SL1500_.jpg'} />
                                    </div>
                                </div>
                            </div>


                            <div className='row'>
                                <hr className='border-hr' />
                                <div className='col-md-12 log-iamge mb-3'>
                                    <div className='row'>
                                        <div className='col-md-6'>
                                            <NormalRadioButtion options={[{ value: 'Yes', label: 'Yes' }, { value: 'No', label: 'no' }]} className='col-form-label-val' label='Select Age' />
                                        </div>
                                        <div className='col-md-6'>
                                            <Normalselect label='Class' size="small" />
                                        </div>
                                        <div className='col-md-12 text-end'>
                                            <NormalButton label='Save' size="small" />
                                            <NormalButton className='ms-2 btn-danger' color='error' label='Clear' size="small" />
                                        </div>
                                    </div>

                                </div>
                                <hr className='border-hr' />
                                <div className='col-md-12 log-iamge mb-3'>
                                    <CloseOutlined color="error" className='float-end' />
                                    <h4 className='title-text'>Machine Detected</h4>
                                    <div className="form-group row">
                                        <label for="staticEmail" className="col-sm-3 col-form-label">Class</label>
                                        <div className="col-sm-9">
                                            <label for="staticEmail" className="col-form-label col-form-label-val">Drive View</label>
                                        </div>
                                    </div>
                                    <div className="form-group row">
                                        <label for="staticEmail" className="col-sm-3 col-form-label">Detected %</label>
                                        <div className="col-sm-9">
                                            <label for="staticEmail" className=" col-form-label col-form-label-val">45 %</label>
                                        </div>
                                    </div>
                                    <div className="form-group row">
                                        <label for="staticEmail" className="col-sm-3 col-form-label">Detected %</label>
                                        <div className="col-sm-9">
                                            <label for="staticEmail" className=" col-form-label col-form-label-val">45 %</label>
                                        </div>
                                    </div>

                                </div>

                                <hr className='border-hr' />
                                <div className='col-md-12 log-iamge mb-3'>
                                    {/* <IconButton color="primary" aria-label="upload picture" component="span"> */}
                                    <CheckCircle color="success" className='float-end' />
                                    {/* </IconButton> */}
                                    <h4 className='title-text'>User Actions</h4>
                                    <div className="form-group row">
                                        <label for="staticEmail" className="col-sm-3 col-form-label">Class</label>
                                        <div className="col-sm-9">
                                            <label for="staticEmail" className="col-form-label col-form-label-val">Drive View</label>
                                        </div>
                                    </div>
                                    <div className="form-group row">
                                        <label for="staticEmail" className="col-sm-3 col-form-label">Detected %</label>
                                        <div className="col-sm-9">
                                            <label for="staticEmail" className="col-form-label col-form-label-val">45 %</label>
                                        </div>
                                    </div>
                                    <div className="form-group row">
                                        <label for="staticEmail" className="col-sm-3 col-form-label">Status </label>
                                        <div className="col-sm-9">
                                            <label for="staticEmail" className=" col-form-label col-form-label-val">Altered</label>
                                        </div>
                                    </div>

                                </div>

                            </div>

                        </div>


                    </div>
                </div>

            </div>
        </div>


    )
}