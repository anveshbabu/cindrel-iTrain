export const history = require('history').createHashHistory({});
// let history = createBrowserHistory();