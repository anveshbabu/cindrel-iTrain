export {MENU,MODULE_MENU} from './menu'
export {EXIST_LOCAL_STORAGE,CONFIG,ALL_BG_PLACEHOLDERS} from './app'